stroka = input()

if stroka == stroka[::-1]:
    print("Палиндром")
else:
    print("Непалиндром")
